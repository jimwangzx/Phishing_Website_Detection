# -*- coding: utf-8 -*-
"""
Created on Sun Jun 20 18:06:39 2021

@author: Ramchandra KC
"""
import pandas as pd
from sklearn.metrics import accuracy_score


data = pd.read_csv('final.csv')
# Sepratating & assigning features and target columns to X & y
y = data['Label']
X = data.drop('Label',axis=1)

# Splitting the dataset into train and test sets: 80-20 split
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X, y,test_size = 0.2, random_state = 12)

from sklearn.neural_network import MLPClassifier

#XGBoost Classification model
mlp = MLPClassifier(alpha=0.001, hidden_layer_sizes=([100,100,100]))

mlp.fit(X_train, y_train)
# instantiate the model
#fit the model
#predicting the target value from the model for the samples
y_test_xgb = mlp.predict(X_test)
y_train_xgb = mlp.predict(X_train)

#computing the accuracy of the model performance
acc_train_xgb = accuracy_score(y_train,y_train_xgb)
acc_test_xgb = accuracy_score(y_test,y_test_xgb)

print("XGBoost: Accuracy on training Data: {:.3f}".format(acc_train_xgb))
print("XGBoost : Accuracy on test Data: {:.3f}".format(acc_test_xgb))

import pickle
pickle.dump(mlp,open('mlp.pickle.dat','wb'))

loaded_model = pickle.load(open("mlp.pickle.dat", "rb"))

print(loaded_model.predict(X_test))



